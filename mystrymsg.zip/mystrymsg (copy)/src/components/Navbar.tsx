"use client";

import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import { User } from "next-auth";
import { Button } from "./ui/button";
import { sign } from "node:crypto";

function Navbar() {
  const { data: session } = useSession();
  const user: User = session?.user as User;

  return (
    <nav className="p-4 md:p-6 shadow-md bg-gray-100 text-black">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
        <a href="#" className="text-xl font-bold mb-4 md:mb-0">
          True Feedback
        </a>
        {session ? (
          <>
            <span>Welcome, {user?.userName || user?.email}</span>
            <span>
              <Link className="mr-2" href={"/dashboard"}>
                <Button>Dashboard</Button>
              </Link>
              <Button onClick={() => signOut()}>Logout</Button>
            </span>
          </>
        ) : (
          <Link href={"/sign-in"}>
            <Button>Sign in</Button>
          </Link>
        )}
      </div>
    </nav>
  );
}

export default Navbar;
