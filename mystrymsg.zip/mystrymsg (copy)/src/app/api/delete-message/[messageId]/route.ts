import { getServerSession, User } from "next-auth";
import { authOptions } from "../../auth/[...nextauth]/options";
import UserModel from "@/model/User";
import dbConnect from "@/lib/dbConnect";
import mongoose from "mongoose";

export async function DELETE(
  request: Request,
  { params }: { params: { messageId: string } }
) {
  await dbConnect();

  const session = await getServerSession(authOptions);
  const user: User = session?.user as User;
  if (!session || !user) {
    return Response.json(
      {
        success: false,
        message: "Not authenticated !!",
      },
      {
        status: 401,
      }
    );
  }
  try {
    const messageId = params.messageId;

    const userId = new mongoose.Types.ObjectId(user._id);
    const udpatResult = await UserModel.updateOne(
      { _id: userId },
      {
        $pull: { messages: { _id: messageId } },
      }
    );
    if (udpatResult.modifiedCount == 0) {
      return Response.json(
        {
          success: false,
          message: "Messages not found",
        },
        {
          status: 404,
        }
      );
    }
    return Response.json(
      {
        success: true,
        message: "Deleted successfully",
      },
      {
        status: 201,
      }
    );
  } catch (error) {
    console.log("Error while fetching", error);
    return Response.json(
      {
        success: false,
        message: "Error while fetching",
      },
      {
        status: 500,
      }
    );
  }
}
