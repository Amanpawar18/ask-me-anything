import { getServerSession, User } from "next-auth";
import { authOptions } from "../auth/[...nextauth]/options";
import UserModel from "@/model/User";
import dbConnect from "@/lib/dbConnect";

export async function POST(req: Request) {
  await dbConnect();

  const session = await getServerSession(authOptions);
  const user: User = session?.user as User;
  if (!session || !user) {
    return Response.json(
      {
        success: false,
        message: "Not authenticated !!",
      },
      {
        status: 401,
      }
    );
  }
  const { acceptMessageFlag } = await req.json();

  try {
    const updateUser = await UserModel.findOneAndUpdate(
      {
        _id: user._id,
      },
      {
        isAcceptingMessage: acceptMessageFlag,
      },
      { new: true }
    );
    if (!updateUser) {
      return Response.json(
        {
          success: false,
          message: "User not found",
        },
        {
          status: 404,
        }
      );
    }
    return Response.json(
      {
        success: true,
        message: "Status updated successfully",
        data: { isAcceptingMessage: user.isAcceptingMessage },
      },
      {
        status: 201,
      }
    );
  } catch (error) {
    console.log("Error updating status", error);
    return Response.json(
      {
        success: false,
        message: "Error updating status",
      },
      {
        status: 500,
      }
    );
  }
}

export async function GET() {
  await dbConnect();

  const session = await getServerSession(authOptions);
  const user: User = session?.user as User;
  if (!session || !user) {
    return Response.json(
      {
        success: false,
        message: "Not authenticated !!",
      },
      {
        status: 401,
      }
    );
  }
  try {
    const activeUser = await UserModel.findOne({
      _id: user._id,
    });
    if (!activeUser) {
      return Response.json(
        {
          success: false,
          message: "User not found",
        },
        {
          status: 404,
        }
      );
    }
    return Response.json(
      {
        success: true,
        message: "Status updated successfully",
        data: {
          isAcceptingMessage: activeUser.isAcceptingMessage,
        },
      },
      {
        status: 201,
      }
    );
  } catch (error) {
    console.log("Error fetching status", error);
    return Response.json(
      {
        success: false,
        message: "Error fetching status",
      },
      {
        status: 500,
      }
    );
  }
}
