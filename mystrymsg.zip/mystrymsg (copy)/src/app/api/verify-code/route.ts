import dbConnect from "@/lib/dbConnect";
import UserModel from "@/model/User";

export async function POST(req: Request) {
  await dbConnect();

  try {
    // const { userName, code } = await req.query();

    // Extract the URL from the request
    const url = new URL(req.url);

    // Access the query parameters from the URL
    const userName = url.searchParams.get("userName");
    const code = url.searchParams.get("code");

    // Decode the user name as sometimes if URL changes value.
    // like space gets converted to %20, etc
    // const decodedUserName = decodeURIComponent(userName);
    const user = await UserModel.findOne({
      userName: userName,
    });
    if (!user) {
      return Response.json(
        {
          success: false,
          message: "User not found !!",
        },
        {
          status: 404,
        }
      );
    }

    const isCodeValid = user.verifyCode == code;
    const isCodeNotExpirted = new Date(user.verifyCodeExpiry) > new Date();
    if (isCodeValid && isCodeNotExpirted) {
      user.isVerified = true;
      user.save();
      return Response.json(
        {
          success: true,
          message: "User is verified !!",
        },
        {
          status: 200,
        }
      );
    }
    return Response.json(
      {
        success: false,
        message: "Code not valie or expired !!",
      },
      {
        status: 400,
      }
    );
  } catch (error) {
    console.log("Error checking verify user", error);
    return Response.json(
      {
        success: false,
        message: "Error checking verify user",
      },
      {
        status: 500,
      }
    );
  }
}
