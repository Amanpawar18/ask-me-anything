import dbConnect from "@/lib/dbConnect";
import UserModel from "@/model/User";
import { z } from "zod";
import { userNameValidation } from "@/schemas/signUpSchema";

const UserNameQuerySchema = z.object({
  userName: userNameValidation,
});

export async function GET(requset: Request) {
  await dbConnect();
  try {
    const { searchParams } = new URL(requset.url);
    const queryParam = {
      userName: searchParams.get("userName"),
    };
    // validate with zod
    const result = UserNameQuerySchema.safeParse(queryParam);
    console.log(result);
    if (!result.success) {
      const userNameErrors = result.error.format().userName?._errors || [];
      return Response.json(
        {
          success: false,
          message:
            userNameErrors?.length > 0
              ? userNameErrors.join(" ")
              : "Error checking username",
        },
        {
          status: 400,
        }
      );
    }
    const { userName } = result.data;
    const existingUser = await UserModel.findOne({
      userName,
      isVerified: true,
    });
    if (existingUser) {
      return Response.json(
        {
          success: false,
          message: "username already exist",
        },
        {
          status: 201,
        }
      );
    }
    return Response.json(
      {
        success: true,
        message: "Username is available",
      },
      {
        status: 201,
      }
    );
  } catch (error) {
    console.log("Error checking username", error);
    return Response.json(
      {
        success: false,
        message: "Error checking username",
      },
      {
        status: 500,
      }
    );
  }
}
