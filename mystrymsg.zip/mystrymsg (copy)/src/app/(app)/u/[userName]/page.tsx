"use client";
import { Button } from "@/components/ui/button";
import React from "react";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import axios, { AxiosError } from "axios";
import { ApiResponse } from "@/types/apiResponse";
import { toast } from "@/hooks/use-toast";
import { useParams } from "next/navigation";

function Page() {
  const form = useForm({
    resolver: zodResolver(
      z.object({
        message: z.string({ message: "Please fill this to send a message." }),
      })
    ),
  });
  const params = useParams<{ userName: string }>();
  const onSubmit = async (data: FormData) => {
    try {
      const response = await axios.post<ApiResponse>("/api/send-message", {
        content: data.message,
        userName: params.userName,
      });
      if (response?.success == false) {
        toast({
          title: "Failure !!",
          description: response?.message,
        });
      }
      toast({
        title: "Sucecss !!",
        description: "Message sent...",
      });
    } catch (error) {
      console.log("Failed to send a message", error);
      const axiosError = error as AxiosError<ApiResponse>;
      const errorMessage = axiosError.response?.data.message;
      toast({
        title: "Failed to send a message",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="my-8 mx-4 md:mx-8 lg:mx-auto p-6 rounded w-full max-w-6xl">
      <div className="mb-4">
        <div className="flex items-center">
          <h1 className="text-4xl font-bold mb-4">
            Drop your anonymous message
          </h1>
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(onSubmit)}
              className="w-2/3 space-y-6"
            >
              <FormField
                control={form.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Ask anything....</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Tell us a little bit about yourself"
                        className="resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button className="flex align-right justify-end" type="submit">
                Submit
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}

export default Page;
